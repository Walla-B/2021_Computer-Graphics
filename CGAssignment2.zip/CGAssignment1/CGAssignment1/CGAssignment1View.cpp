﻿#define M_PI_2 1.57079632679489661923
// CGAssignment1View.cpp: CCGAssignment1View 클래스의 구현
//
#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "CGAssignment1.h"
#endif
#include "math.h"
#include "CGAssignment1Doc.h"
#include "CGAssignment1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCGAssignment1View

IMPLEMENT_DYNCREATE(CCGAssignment1View, CView)

BEGIN_MESSAGE_MAP(CCGAssignment1View, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CCGAssignment1View::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
END_MESSAGE_MAP()

// CCGAssignment1View 생성/소멸

CCGAssignment1View::CCGAssignment1View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CCGAssignment1View::~CCGAssignment1View()
{
}

BOOL CCGAssignment1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CCGAssignment1View 그리기

void CCGAssignment1View::OnDraw(CDC* /*pDC*/)
{
	CCGAssignment1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	DrawGLScene();
	Invalidate(FALSE);
}


// CCGAssignment1View 인쇄


void CCGAssignment1View::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CCGAssignment1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CCGAssignment1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CCGAssignment1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


void CCGAssignment1View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}

BOOL CCGAssignment1View::SetDevicePixelFormat(HDC hdc) {
	int pixelformat;

	PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW |
		PFD_SUPPORT_OPENGL |
		PFD_GENERIC_FORMAT |
		PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
		32,
		0,0,0,0,0,0,
		8,
		0,
		8,
		0,0,0,0,
		16,
		0,
		0,
		PFD_MAIN_PLANE,
		0,
		0,0,0
	};

	if ((pixelformat = ChoosePixelFormat(hdc, &pfd)) == FALSE) {
		MessageBox(LPCTSTR("ChoosePixelFormat failed"), LPCTSTR("Error"), MB_OK);
		return FALSE;
	}

	if (SetPixelFormat(hdc, pixelformat, &pfd) == FALSE) {
		MessageBox(LPCTSTR("SetPixelFormat failed"), LPCTSTR("Error"), MB_OK);
		return FALSE;
	}

	return TRUE;
}




// CCGAssignment1View 진단

#ifdef _DEBUG
void CCGAssignment1View::AssertValid() const
{
	CView::AssertValid();
}

void CCGAssignment1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCGAssignment1Doc* CCGAssignment1View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCGAssignment1Doc)));
	return (CCGAssignment1Doc*)m_pDocument;
}
#endif //_DEBUG


// CCGAssignment1View 메시지 처리기


int CCGAssignment1View::OnCreate(LPCREATESTRUCT lpCreateStruct) {
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.	
	m_hDC = GetDC()->m_hDC;

	if (!SetDevicePixelFormat(m_hDC)) {
		return -1;
	}

	m_hglRC = wglCreateContext(m_hDC);
	wglMakeCurrent(m_hDC, m_hglRC);

	InitGL();

	return 0;
}


void CCGAssignment1View::OnDestroy() {
	CView::OnDestroy();

	// TODO: 여기에 메시지 처리기 코드를 추가합니다.

	// deselect rendering context and delete it
	wglMakeCurrent(m_hDC, NULL);
	wglDeleteContext(m_hglRC);
}

void CCGAssignment1View::InitGL(GLvoid) {
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	m_cameramode = 1;
	m_mouseMove = FALSE;
	m_camera_x = m_camera_y = 0.0;
	m_camera_z = 30.0;

	m_lookat_x = m_lookat_y = m_lookat_z = 0.0;
	m_planeCoord_x = m_planeCoord_y = m_planeCoord_z = 0.0;
	m_pitch = m_yaw = 0;
	m_speed = 0;

}



void CCGAssignment1View::ResizeGLScene(GLsizei width, GLsizei height) {
	if (height == 0) height = 1;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void CCGAssignment1View::OnSize(UINT nType, int cx, int cy) {
	CView::OnSize(nType, cx, cy);

	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	ResizeGLScene(cx, cy);
}

void CCGAssignment1View::DrawGLScene(void) {

	// clear screen and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	// Set Camera properties by camera mode
	if (m_cameramode == 1) { // If cameramode is 1, just track plane at stationary point
		
		m_lookat_x = m_planeCoord_x;
		m_lookat_y = m_planeCoord_y;
		m_lookat_z = m_planeCoord_z;
	}
	else if (m_cameramode == 2) {	// If cameramode is 2, track & follow plane
		m_lookat_x = m_planeCoord_x;
		m_lookat_y = m_planeCoord_y;
		m_lookat_z = m_planeCoord_z;
		
		m_camera_x = m_planeCoord_x;
		m_camera_y = m_planeCoord_y - 20;
		m_camera_z = m_planeCoord_z + 5;
	}

	gluLookAt(m_camera_x, m_camera_y, m_camera_z, m_lookat_x, m_lookat_y, m_lookat_z, 0.f, 1.f, 0.f);

	GLdouble angleX, angleY;
	
	// if mouse is moving, rotate everything with its position
	if (m_mouseMove) {
		angleX = 1 * (m_mouseCurrentPoint.x - m_mouseAnchorPoint.x);
		angleY = 1 * (m_mouseCurrentPoint.y - m_mouseAnchorPoint.y);
		glRotatef(angleX, 0, 1, 0);
		glRotatef(angleY, 1, 0, 0);
	}

	// yaw and pitch with speed variable changing plane's position
	m_planeCoord_x = m_planeCoord_x + 0.1 * m_speed * -m_yaw;
	m_planeCoord_y = m_planeCoord_y + m_speed;
	m_planeCoord_z = m_planeCoord_z + 0.1 * m_speed * m_pitch;

	// Draw stars and Plane
	m_B913038.DrawStars();
	m_B913038.DrawPlane(m_planeCoord_x,m_planeCoord_y,m_planeCoord_z,m_pitch,m_yaw);

	// swap buffer
	SwapBuffers(m_hDC);
}


void CCGAssignment1View::OnLButtonDown(UINT nFlags, CPoint point) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	m_mouseMove = TRUE;
	m_mouseAnchorPoint = point;

	CView::OnLButtonDown(nFlags, point);
}

void CCGAssignment1View::OnLButtonUp(UINT nFlags, CPoint point) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	m_mouseMove = FALSE;

	CView::OnLButtonUp(nFlags, point);
}

void CCGAssignment1View::OnRButtonDown(UINT nFlags, CPoint point) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CView::OnRButtonDown(nFlags, point);
}

void CCGAssignment1View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CCGAssignment1View::OnMouseMove(UINT nFlags, CPoint point) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	m_mouseCurrentPoint = point;
	CView::OnMouseMove(nFlags, point);
}


void CCGAssignment1View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	switch (nChar) {
	case VK_LEFT:							//Arrow Keys modify m_camera_x and m_camera_y values only at cameramode 1
		if (m_cameramode == 1) {
			m_camera_x -= 1;
		}
		break;
	case VK_RIGHT:
		if (m_cameramode == 1) {
			m_camera_x += 1;
		}
		break;
	case VK_UP:
		if (m_cameramode == 1) {
			m_camera_y += 1;
		}
		break;
	case VK_DOWN:
		if (m_cameramode == 1) {
			m_camera_y -= 1;
		}
		break;
	case 0x31:			//Keyboard 1
	case VK_NUMPAD1:	//Numpad 1	
		m_cameramode = 1;					// Change camera mode
		m_camera_x = m_camera_y = 0.0;		// Move camera to default position when '1' key is pressed.
		m_camera_z = 30.0;
		break;
	case 0x32:			//Keyboard 2
	case VK_NUMPAD2:	//Numpad 2
		m_cameramode = 2;					// Change camera mode
		break;
	case VK_ADD:
		m_speed += 0.001;					// Accelerate
		break;
	case VK_SUBTRACT:			
		if (m_speed > 0.0) {				// Decelerate but only when speed is above zero
			m_speed -= 0.001;
		}
		else
			m_speed = 0.0;
		break;
	case 0x57:	//W
		m_pitch += 5;						// Controlls pitch and yaw variables
		break;
	case 0x41:	//A
		m_yaw += 5;
		break;
	case 0x53:	//S
		m_pitch -= 5;
		break;
	case 0x44:  //D
		m_yaw -= 5;
		break;
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CCGAssignment1View::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) {
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CView::OnKeyUp(nChar, nRepCnt, nFlags);
}
